// package controller;
// import model.ListItems;

// public class TestDB {
//     private ListItems testItems;
//     RegisterController registerController;


//     public static void main(String[] args){
        
//     }


//     public void demoStore(){
//         registerController.registerStaff("Michael", "Scott", 1000, "password");
//         registerController.registerStaff("Jim", "Halpert", 1001, "password");
//         registerController.registerStaff("Kevin", "Malone", 1002, "password");

//         registerController.registerCustomer("Robert", "California", "robertcalifornia@dundermifflin.com", "winecellar");
//         registerController.registerCustomer("Jan", "Levinson", "janlevinson@scentedcandles.com", "password");
//         registerController.registerCustomer("Example", "Customer", "example@example.com", "password");

//         // testItems.createProduct("Macbook", "Apple", 1990.00, "Silver", "12 inch");
//         // testItems.createProduct("28 inch monitor", "Samsung", 500.00, "Black", "28 inch");
//         // testItems.createProduct("Charging cord", "Apple", 80.00, "White", "1 metre");
//         // testItems.createProduct("iPad", "Apple", 700.00, "Black", "11 inch");
//         // testItems.createProduct("Galaxy Phone", "Samsung", 1400.00, "Silver", "128GB");
//         // testItems.createProduct("Power Bank", "Lenovo", 80.00, "White", "100 watt");
//         // testItems.createProduct("Television", "Lenovo", 1863.95, "Black", "60 inch");
//         // testItems.createProduct("Headphones", "Sony", 379.00, "Silver", "OS");
//         // testItems.createProduct("Watch", "Sony", 634.00, "White", "12 mm");

//     }



// }
